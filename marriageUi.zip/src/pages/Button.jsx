export const month = [
  {
    id: "1",
    value: "jan"

  },

  {
    id: "2",
    value: "feb"
  },
  {
    id: "3",
    value: "march"

  }
]

export const year = [
  {
    id: "1",
    value: "2000"
  }, {
    id: "1",
    value: "2001"
  }, {
    id: "1",
    value: "2002"
  }
]